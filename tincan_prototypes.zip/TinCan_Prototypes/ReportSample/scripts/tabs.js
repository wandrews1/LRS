/*
* Skeleton V1.1
* Copyright 2011, Dave Gamache
* www.getskeleton.com
* Free to use under the MIT license.
* http://www.opensource.org/licenses/mit-license.php
* 8/17/2011
*/


$(document).ready(function() {

    /* Tabs Activiation
    ================================================== */

    var tabs = $('ul.tabs');

    tabs.each(function(i) {

        //Get all tabs
        var tab = $(this).find('> li > a');
        tab.click(function(e) {

            //Get Location of tab's content
            var href = $(this).attr('href'),
                hashStart = href.indexOf("#"),
                contentLocation;

            //Let go if not a hashed one
            if (hashStart === -1) {
                return;
            }

            e.preventDefault();

            contentLocation = href.substring(hashStart);

            //Make Tab Active
            tab.removeClass('active');
            $(this).addClass('active');

            //Show Tab Content & add active class
            $(contentLocation).show().addClass('active').siblings().hide().removeClass('active');
        });
    });
});
